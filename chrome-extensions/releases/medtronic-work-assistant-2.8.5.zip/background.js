// Background script for handling new tab monitoring and closing
importScripts('pending_sync.js');

let monitoredUrls = new Set();
let mainTabId = null;
chrome.storage.session.get('mainTabId').then(r => { if (mainTabId === null && r.mainTabId != null) mainTabId = r.mainTabId; });
function setMainTabId(id) { mainTabId = id; chrome.storage.session.set({ mainTabId: id }); }
let cornerstonePopupCandidateTabIds = new Set();

// 记录所有 SCORM 相关 tab
let scormTabIds = new Set();

// ── 注入视频控制到指定 tab ──
function injectVideoControl(tabId, action) {
  const code = action === 'skip'
    ? `(function(){
        function skipAll(doc){
          try{
            doc.querySelectorAll('video').forEach(v=>{
              if(v.duration&&isFinite(v.duration)){v.currentTime=v.duration-0.1;}
            });
          }catch(e){}
          try{
            Array.from(doc.querySelectorAll('iframe')).forEach(f=>{
              try{skipAll(f.contentDocument||f.contentWindow.document);}catch(e){}
            });
          }catch(e){}
        }
        skipAll(document);
      })()`
    : `(function(speed){
        function applyAll(doc){
          try{
            doc.querySelectorAll('video').forEach(v=>{
              try{v.playbackRate=speed;}catch(e){}
            });
          }catch(e){}
          try{
            Array.from(doc.querySelectorAll('iframe')).forEach(f=>{
              try{applyAll(f.contentDocument||f.contentWindow.document);}catch(e){}
            });
          }catch(e){}
        }
        applyAll(document);
      })(${action})`;

  chrome.scripting.executeScript({
    target: { tabId, allFrames: true },
    func: action === 'skip'
      ? function() {
          document.querySelectorAll('video').forEach(v => {
            if (v.duration && isFinite(v.duration)) v.currentTime = v.duration - 0.1;
          });
        }
      : new Function(`document.querySelectorAll('video').forEach(v=>{try{v.playbackRate=${action};}catch(e){}});`)
  }).catch(() => {});
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('Background script received message:', request);

  if (request.action === 'monitorNewTab') {
    const url = request.url;
    if (sender && sender.tab && sender.tab.id) {
      setMainTabId(sender.tab.id);
    }
    monitoredUrls.add(url);
    sendResponse({ success: true });
  }

  if (request.action === 'cornerstoneAutoClickStarted') {
    // 课程弹出页里的 content script 也会发此消息，若被当成主页签，弹出页就永远不会被关闭
    const t = sender && sender.tab;
    const isPopup = t && (t.openerTabId != null || cornerstonePopupCandidateTabIds.has(t.id) || !/lms-learner-home|\/home/i.test(t.url || ''));
    if (t && t.id && !isPopup) {
      setMainTabId(t.id);
    }
    sendResponse({ success: true });
  }

  // 视频跳过：注入到所有 SCORM tab
  if (request.action === 'videoSkip') {
    const targets = scormTabIds.size > 0 ? [...scormTabIds] : [];
    // 也包含发送方 tab
    if (sender && sender.tab && sender.tab.id) targets.push(sender.tab.id);
    const unique = [...new Set(targets)];
    unique.forEach(tabId => {
      chrome.scripting.executeScript({
        target: { tabId, allFrames: true },
        func: () => {
          document.querySelectorAll('video').forEach(v => {
            try { if (v.duration && isFinite(v.duration)) v.currentTime = v.duration - 0.1; } catch(e) {}
          });
        }
      }).catch(() => {});
    });
    sendResponse({ success: true, tabs: unique.length });
  }

  // 视频变速：注入到所有 SCORM tab
  if (request.action === 'videoSpeed') {
    const speed = request.speed || 1;
    const targets = scormTabIds.size > 0 ? [...scormTabIds] : [];
    if (sender && sender.tab && sender.tab.id) targets.push(sender.tab.id);
    const unique = [...new Set(targets)];
    unique.forEach(tabId => {
      chrome.scripting.executeScript({
        target: { tabId, allFrames: true },
        func: (s) => {
          document.querySelectorAll('video').forEach(v => {
            try { v.playbackRate = s; } catch(e) {}
          });
        },
        args: [speed]
      }).catch(() => {});
    });
    sendResponse({ success: true, tabs: unique.length });
  }

  // Workday 职务申请批量：按序号打开新标签页，由 content_workday_req.js 认领任务并填写
  if (request.action === 'wdReqBatchOpen') {
    (async () => {
      const { wdReqJobs = {} } = await chrome.storage.session.get('wdReqJobs');
      let opened = 0;
      for (const index of request.indexes || []) {
        const tab = await chrome.tabs.create({ url: request.url, active: false });
        wdReqJobs[tab.id] = { index };
        opened++;
      }
      await chrome.storage.session.set({ wdReqJobs });
      sendResponse({ success: true, opened });
    })();
    return true;
  }

  if (request.action === 'wdReqGetJob') {
    (async () => {
      const { wdReqJobs = {} } = await chrome.storage.session.get('wdReqJobs');
      sendResponse(sender?.tab?.id != null ? wdReqJobs[sender.tab.id] || null : null);
    })();
    return true;
  }

  return true;
});

function shouldCloseCornerstonePopup(tab) {
  if (!tab || !tab.id || mainTabId === null || tab.id === mainTabId) return false;

  const url = tab.url || '';
  const pendingUrl = tab.pendingUrl || '';
  const combinedUrl = `${url} ${pendingUrl}`;
  const openedFromMainTab = tab.openerTabId === mainTabId || cornerstonePopupCandidateTabIds.has(tab.id);

  if (openedFromMainTab) return true;

  if (combinedUrl.includes('medtronic.csod.com') && cornerstonePopupCandidateTabIds.has(tab.id)) {
    return true;
  }

  return false;
}

function closeCornerstonePopupTab(tabId, reason, delay = 2000) {
  if (!tabId || tabId === mainTabId) return;
  setTimeout(() => {
    chrome.storage.local.get(['isAutoClickRunning'], (r) => {
      if (!r.isAutoClickRunning) { cornerstonePopupCandidateTabIds.delete(tabId); return; }
      closeNow();
    });
    function closeNow() {
    chrome.tabs.get(tabId, tab => {
      if (chrome.runtime.lastError || !tab || tab.id === mainTabId) return;
      console.log(`Closing Cornerstone popup tab (${reason}):`, tab.url || tab.pendingUrl || tab.id);
      chrome.tabs.remove(tabId, () => {
        cornerstonePopupCandidateTabIds.delete(tabId);
        if (chrome.runtime.lastError) {
          console.log('Close Cornerstone popup failed:', chrome.runtime.lastError.message);
        }
      });
    });
    }
  }, delay);
}

// 只关闭新建且不是主tabId的标签页
chrome.tabs.onCreated.addListener((tab) => {
  console.log('New tab created:', tab.url, 'tabId:', tab.id);
  // 记录 SCORM tab
  if (tab.url && tab.url.includes('medtronic.csod.com')) {
    scormTabIds.add(tab.id);
  }

  // 只有自动点击运行期间才关闭弹出页；用户手动打开/点击 Cornerstone 链接不能被误关
  if (mainTabId !== null && tab.id !== mainTabId &&
      (tab.openerTabId === mainTabId || /medtronic\.csod\.com/.test(`${tab.url || ''} ${tab.pendingUrl || ''}`))) {
    chrome.storage.local.get(['isAutoClickRunning'], (r) => {
      if (!r.isAutoClickRunning) return;
      cornerstonePopupCandidateTabIds.add(tab.id);
      closeCornerstonePopupTab(tab.id, 'opened from Cornerstone main tab');
    });
  }

  for (const monitoredUrl of monitoredUrls) {
    if (tab.url && (tab.url.includes(monitoredUrl) || tab.url.includes(monitoredUrl.replace('javascript:void(0);', '')))) {
      if (mainTabId !== null && tab.id !== mainTabId) {
        console.log('Found monitored URL in new tab, closing:', tab.url);
        setTimeout(() => {
          chrome.tabs.remove(tab.id, () => {
            console.log('New tab closed:', tab.id);
          });
        }, 2000);
        monitoredUrls.delete(monitoredUrl);
      }
      break;
    }
  }
});

// 只关闭新建且不是主tabId的标签页
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  // 记录 SCORM tab
  if (tab.url && tab.url.includes('medtronic.csod.com')) {
    scormTabIds.add(tabId);
  }

  if (shouldCloseCornerstonePopup(tab)) {
    closeCornerstonePopupTab(tabId, 'Cornerstone popup updated');
    return;
  }

  if (changeInfo.status === 'complete' && tab.url) {
    for (const monitoredUrl of monitoredUrls) {
      if (tab.url.includes(monitoredUrl) || tab.url.includes(monitoredUrl.replace('javascript:void(0);', ''))) {
        if (mainTabId !== null && tabId !== mainTabId) {
          console.log('Found monitored URL, closing tab:', tab.url);
          setTimeout(() => {
            chrome.tabs.remove(tabId, () => {
              console.log('Tab closed:', tabId);
            });
          }, 2000);
          monitoredUrls.delete(monitoredUrl);
        }
        break;
      }
    }
  }
});

// tab 关闭时清理 scormTabIds
chrome.tabs.onRemoved.addListener((tabId) => {
  scormTabIds.delete(tabId);
  cornerstonePopupCandidateTabIds.delete(tabId);
});

console.log('Background script loaded');

// 右键菜单只保留“中止所有指令”；其余配置都在左键弹窗里
function updateContextMenu() {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: 'stopAllActions',
      title: '中止所有插件指令',
      contexts: ['action']
    });
  });
}

function stopAllActions() {
  chrome.storage.local.set({
    isAutoClickRunning: false,
    currentClickCount: 0,
    targetClickCount: 0,
    markCompleteCount: 0,
    clickedLaunchHrefs: [],
    launchAttempts: {},
    noButtonRefreshAttempts: 0,
    ehrLoginAttempts: 0
  }, () => {
    const targets = [
      ['*://medtronic.csod.com/*', 'stopAllActions'],
      ['*://ehr.medtronic.com.cn/*', 'stopAllActions'],
      ['https://khplm.medtronic.com.cn/*', 'stopWindchillActions']
    ];
    targets.forEach(([pattern, action]) => {
      chrome.tabs.query({ url: pattern }, (tabs) => {
        tabs.forEach(tab => chrome.tabs.sendMessage(tab.id, { action }, () => { void chrome.runtime.lastError; }));
      });
    });
    chrome.notifications.create({
      type: 'basic',
      iconUrl: 'icon.png',
      title: 'Medtronic Work Assistant',
      message: '所有插件指令已中止',
      priority: 2
    });
  });
}

function reloadCornerstoneTabs() {
  chrome.tabs.query({ url: '*://medtronic.csod.com/*' }, (tabs) => tabs.forEach(tab => chrome.tabs.reload(tab.id)));
}

chrome.runtime.onInstalled.addListener(updateContextMenu);
chrome.runtime.onStartup.addListener(updateContextMenu);

chrome.contextMenus.onClicked.addListener((info) => {
  if (info.menuItemId === 'stopAllActions') stopAllActions();
});

chrome.runtime.onMessage.addListener((request) => {
  if (request && request.action === 'stopAllFromPopup') stopAllActions();
});
// 监听设置变化，动态更新菜单和定时任务
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local') {
    if (changes.autoClickEnabled || changes.autoClosePopup) {
      reloadCornerstoneTabs();
    }
    if (changes.dailyOpenEnabled || changes.dailyOpenTime) {
      updateDailyAlarm();
    }
    if (changes.windchillDailyOpenEnabled || changes.windchillDailyOpenTime) {
      updateWindchillDailyAlarm();
    }
  }
});

// 计算下一个运行时间
function getNextRunTime(targetTimeStr = "09:00") {
  const [hours, minutes] = targetTimeStr.split(':').map(Number);
  const now = new Date();
  const nextRun = new Date(now);
  nextRun.setHours(hours, minutes, 0, 0);

  // 如果今天已经过了设定时间，则设为明天
  if (now > nextRun) {
    nextRun.setDate(now.getDate() + 1);
  }
  return nextRun.getTime();
}

// 更新定时任务
function updateDailyAlarm() {
  chrome.storage.local.get(['dailyOpenEnabled', 'dailyOpenTime'], (result) => {
    if (result.dailyOpenEnabled) {
      // 默认 09:00
      const timeStr = result.dailyOpenTime || "09:00";
      chrome.alarms.create('dailyOpenPages', {
        when: getNextRunTime(timeStr),
        periodInMinutes: 1440 // 24小时
      });
      console.log(`Daily alarm set for: ${new Date(getNextRunTime(timeStr)).toLocaleString()} (Target: ${timeStr})`);
    } else {
      chrome.alarms.clear('dailyOpenPages');
      console.log('Daily alarm cleared');
    }
  });
}

// 监听定时任务触发
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'dailyOpenPages') {
    console.log('Daily alarm triggered, opening pages...');
    const urls = [
      'http://ehr.medtronic.com.cn/'
    ];

    urls.forEach(url => {
      chrome.tabs.create({ url: url });
    });
  }
});

// 初始化或更新定时器
updateDailyAlarm();

// ── Windchill：Basic Auth 凭据与每日打开 ──
function getWindchillCredentials(callback) {
  chrome.storage.local.get(['windchillUsername', 'windchillPassword', 'Login1', 'Password1'], (result) => {
    const own = result.windchillUsername && result.windchillPassword;
    callback({
      username: (own ? result.windchillUsername : result.Login1) || '',
      password: (own ? result.windchillPassword : result.Password1) || ''
    });
  });
}

// 同一请求只提交一次凭据，密码错误时不让 Chrome 反复重试导致账号锁定
const windchillAuthTried = new Set();

chrome.webRequest.onAuthRequired.addListener(
  (details, callback) => {
    if (windchillAuthTried.has(details.requestId)) {
      callback({});
      return;
    }
    getWindchillCredentials((credentials) => {
      if (!credentials.username || !credentials.password) {
        callback({});
        return;
      }
      windchillAuthTried.add(details.requestId);
      if (windchillAuthTried.size > 200) windchillAuthTried.delete(windchillAuthTried.values().next().value);
      callback({ authCredentials: credentials });
    });
  },
  { urls: ['https://khplm.medtronic.com.cn/*'] },
  ['asyncBlocking']
);

function updateWindchillDailyAlarm() {
  chrome.storage.local.get(['windchillDailyOpenEnabled', 'windchillDailyOpenTime'], (result) => {
    if (!result.windchillDailyOpenEnabled) {
      chrome.alarms.clear('windchillDailyOpen');
      return;
    }
    chrome.alarms.create('windchillDailyOpen', {
      when: getNextRunTime(result.windchillDailyOpenTime || '09:00'),
      periodInMinutes: 1440
    });
  });
}

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'windchillDailyOpen') {
    chrome.tabs.create({ url: 'https://khplm.medtronic.com.cn/Windchill/app/#ptc1/homepage' });
  }
});

updateWindchillDailyAlarm();
