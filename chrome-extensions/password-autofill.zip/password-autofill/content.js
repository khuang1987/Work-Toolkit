// 自动填充指定的账号密码
function autoFillCredentials() {
  console.log('开始执行自动填充函数');

  // 定义多个可能的选择器
  const selectors = {
    windchill: {
      username: [
        'input[name*="signatureEngine_username"]',
        'input[type="text"][name*="signatureEngine_username"]',
        'input[name*="___signatureEngine_username___textbox"]',
        '//input[contains(@name, "signatureEngine_username")]',
        '//input[contains(@name, "___signatureEngine_username___textbox")]',
        'input[name="j_username"]',
        '#j_username',
        'input[name="username"]',
        'input[id="username"]'
      ],
      password: [
        'input[name*="signatureEngine_password"]',
        'input[type="password"][name*="signatureEngine_password"]',
        'input[name*="___signatureEngine_password___textbox"]',
        '//input[contains(@name, "signatureEngine_password")]',
        '//input[contains(@name, "___signatureEngine_password___textbox")]',
        'input[name="j_password"]',
        '#j_password',
        'input[name="password"]',
        'input[id="password"]'
      ]
    },
    ehr: {
      username: [
        'input[name="Login1"]',
        '#Login1',
        'input.Login[type="text"]',
        'input[placeholder*="请输入用户名"]',
        'input[type="text"][maxlength="50"]'
      ],
      password: [
        'input[name="Password1"]',
        '#Password1',
        'input.password.pwd-input',
        'input[type="password"][maxlength="50"]',
        'input[placeholder*="请输入密码"]'
      ]
    }
  };

  // 使用不同的选择器方法尝试查找元素
  function findElement(selectorList) {
    // 首先在主文档中查找
    for (const selector of selectorList) {
      try {
        if (selector.startsWith('//')) {
          // XPath选择器
          const element = document.evaluate(selector, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
          if (element) return element;
        } else {
          // CSS选择器
          const element = document.querySelector(selector);
          if (element) return element;
        }
      } catch (error) {
        console.log(`选择器 ${selector} 查找失败:`, error);
      }
    }

    // 如果主文档中没找到，尝试在所有iframe中查找
    const iframes = document.getElementsByTagName('iframe');
    for (const iframe of iframes) {
      try {
        const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
        for (const selector of selectorList) {
          try {
            if (selector.startsWith('//')) {
              const element = iframeDoc.evaluate(selector, iframeDoc, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
              if (element) return element;
            } else {
              const element = iframeDoc.querySelector(selector);
              if (element) return element;
            }
          } catch (error) {
            console.log(`iframe中选择器 ${selector} 查找失败:`, error);
          }
        }
      } catch (error) {
        console.log('访问iframe失败:', error);
      }
    }
    return null;
  }

  // 定期检查元素是否存在并填充
  function tryFill(retryCount = 0, maxRetries = 20) {
    if (retryCount >= maxRetries) {
      console.log('达到最大重试次数，停止尝试');
      return;
    }

    // 根据当前URL选择合适的选择器和存储键
    let currentSelectors;
    let storageKeys;

    const currentUrl = window.location.href;
    console.log('当前页面URL:', currentUrl);

    if (currentUrl.includes('khplm.medtronic.com.cn')) {
      console.log('识别为Windchill系统');
      currentSelectors = selectors.windchill;
      storageKeys = { username: 'username', password: 'password' };
    } else if (currentUrl.includes('ehr.medtronic.com.cn/Authentication/Login')) {
      console.log('识别为EHR系统登录页面');
      currentSelectors = selectors.ehr;
      storageKeys = { username: 'Login1', password: 'Password1' };
    } else if (currentUrl.includes('medtronic.csod.com')) {
      console.log('识别为Cornerstone系统，跳过自动填充');
      return; // Cornerstone系统不需要自动填充，只需要自动点击功能
    } else {
      console.log('不支持的网站:', currentUrl);
      return;
    }

    const usernameInput = findElement(currentSelectors.username);
    const passwordInput = findElement(currentSelectors.password);

    // 添加调试日志
    console.log('用户名输入框是否找到:', !!usernameInput);
    console.log('密码输入框是否找到:', !!passwordInput);
    if (usernameInput) {
      console.log('找到的用户名输入框:', {
        id: usernameInput.id,
        name: usernameInput.name,
        class: usernameInput.className,
        type: usernameInput.type,
        placeholder: usernameInput.placeholder
      });
    }
    if (passwordInput) {
      console.log('找到的密码输入框:', {
        id: passwordInput.id,
        name: passwordInput.name,
        class: passwordInput.className,
        type: passwordInput.type,
        placeholder: passwordInput.placeholder
      });
    }

    if (!usernameInput || !passwordInput) {
      console.log(`未找到输入框，将在500ms后重试 (${retryCount + 1}/${maxRetries})`);
      setTimeout(() => tryFill(retryCount + 1, maxRetries), 500);
      return;
    }

    // 填充账号密码
    console.log('找到输入框，开始填充账号密码...');
    // 从chrome.storage获取保存的账号密码
    chrome.storage.local.get([storageKeys.username, storageKeys.password], function (result) {
      const username = result[storageKeys.username];
      const password = result[storageKeys.password];

      console.log('是否获取到用户名:', !!username);
      console.log('是否获取到密码:', !!password);

      if (username && password) {
        usernameInput.value = username;
        passwordInput.value = password;

        // 触发所有可能的事件
        const events = ['input', 'change', 'blur', 'focus'];
        events.forEach(eventType => {
          usernameInput.dispatchEvent(new Event(eventType, { bubbles: true }));
          passwordInput.dispatchEvent(new Event(eventType, { bubbles: true }));
        });

        console.log('自动填充完成');

        // 尝试聚焦验证码输入框 (针对EHR系统)
        if (currentUrl.includes('ehr.medtronic.com.cn')) {
          setTimeout(() => {
            const captchaInput = document.querySelector('input[placeholder*="验证码"]') ||
              document.querySelector('input[name*="Code"]') ||
              document.querySelector('input[name*="yzm"]');

            if (captchaInput) {
              console.log('找到验证码输入框，进行聚焦');
              captchaInput.focus();
              captchaInput.click();
            } else {
              console.log('未找到验证码输入框');
            }
          }, 500);
        }

        // 如果是 Windchill 系统，3秒后自动点击完成任务按钮（只点击一次）
        if (currentUrl.includes('khplm.medtronic.com.cn')) {
          console.log('Windchill 系统：3秒后自动点击完成任务按钮');
          setTimeout(() => {
            const completeButton = document.querySelector('button[id*="P"][name="complete"]');
            if (completeButton && !completeButton.hasAttribute('data-clicked')) {
              console.log('找到完成任务按钮，准备点击');
              // 标记按钮已被点击，防止重复点击
              completeButton.setAttribute('data-clicked', 'true');
              completeButton.click();
              console.log('已点击完成任务按钮');
            } else if (completeButton && completeButton.hasAttribute('data-clicked')) {
              console.log('完成任务按钮已被点击过，跳过');
            } else {
              console.log('未找到完成任务按钮');
            }
          }, 3000);
        }
      } else {
        console.log('未找到保存的账号密码');
      }
    });
  }

  // 开始尝试填充
  tryFill();
}

// 创建悬浮按钮
function createFloatingButton() {
  const button = document.createElement('button');
  button.id = 'autoClickButton';
  button.style.cssText = `
    position: fixed;
    left: 20px;
    top: 50%;
    transform: translateY(-50%);
    z-index: 10000;
    width: 50px;
    height: 50px;
    background-color: #0070c0;
    color: white;
    border: none;
    border-radius: 50%;
    cursor: pointer;
    font-size: 13px;
    box-shadow: 0 2px 5px rgba(0,0,0,0.2);
    transition: all 0.3s ease;
    display: flex;
    align-items: center;
    justify-content: center;
    line-height: 1.2;
    text-align: center;
    padding: 0;
  `;

  // 鼠标悬停效果
  button.onmouseover = () => {
    if (!button.disabled) {
      // 根据当前运行状态设置悬停颜色
      if (isAutoClickRunning) {
        button.style.backgroundColor = '#45a049'; // 绿色悬停
      } else {
        button.style.backgroundColor = '#005999'; // 蓝色悬停
      }
      button.style.transform = 'translateY(-50%) scale(1.05)';
    }
  };
  button.onmouseout = () => {
    if (!button.disabled) {
      // 根据当前运行状态恢复颜色
      if (isAutoClickRunning) {
        button.style.backgroundColor = '#4CAF50'; // 绿色
      } else {
        button.style.backgroundColor = '#0070c0'; // 蓝色
      }
      button.style.transform = 'translateY(-50%) scale(1)';
    }
  };

  document.body.appendChild(button);
  return button;
}

// 更新按钮文本和状态
function updateButtonText(remainingCount) {
  const button = document.getElementById('autoClickButton');
  if (button) {
    if (isAutoClickRunning) {
      // 运行中显示剩余次数
      button.innerHTML = `剩余<br>${remainingCount}次`;
    } else {
      // 未运行时显示总次数
      button.innerHTML = `点击<br>${remainingCount}次`;
    }
  }
}

// 初始化按钮文本（显示设置中的点击次数）
function initializeButtonText() {
  chrome.storage.local.get(['clickCount'], function (result) {
    const clickCount = result.clickCount || 30;
    updateButtonText(clickCount);
  });
}

// 更新按钮状态
function updateButtonState(isRunning) {
  const button = document.getElementById('autoClickButton');
  if (button) {
    if (isRunning) {
      button.style.backgroundColor = '#4CAF50'; // 绿色
      button.style.cursor = 'not-allowed';
    } else {
      button.style.backgroundColor = '#0070c0'; // 蓝色
      button.style.cursor = 'pointer';
    }
  }
}

// 自动点击功能（用于 Cornerstone 页面）
let isAutoClickRunning = false;
let currentClickCount = 0;
let targetClickCount = 0;
let noButtonTimeout = null; // 用于跟踪无按钮超时
let consecutiveNoButtonChecks = 0; // 连续未找到可点击按钮的次数
let lastSoftReloadAt = 0; // 最近一次软刷新时间戳(ms)
let refreshAttemptCount = 0; // 刷新页面尝试计数（找不到按钮时触发）
// 兼容存储字段名称
let noButtonRefreshAttempts = 0; // 与存储同步，用于跨刷新累计

// 页面加载时检查是否需要继续自动点击或清理状态
function checkAndContinueAutoClick() {
  console.log('页面加载，检查自动点击状态');

  // 检查是否在自动点击过程中
  chrome.storage.local.get(['isAutoClickRunning', 'currentClickCount', 'targetClickCount', 'autoClickEnabled'], function (result) {
    // 如果自动点击功能未开启，清理所有状态
    if (!result.autoClickEnabled) {
      console.log('自动点击功能未开启，清理所有状态');
      cleanupAutoClickState();
      return;
    }

    // 如果正在自动点击过程中，继续执行
    if (result.isAutoClickRunning && result.currentClickCount < result.targetClickCount) {
      console.log('检测到自动点击进行中，恢复状态继续执行');
      console.log('恢复前的状态: isAutoClickRunning=', isAutoClickRunning, 'currentClickCount=', currentClickCount, 'targetClickCount=', targetClickCount);
      isAutoClickRunning = true;
      currentClickCount = result.currentClickCount;
      targetClickCount = result.targetClickCount;
      console.log('恢复后的状态: isAutoClickRunning=', isAutoClickRunning, 'currentClickCount=', currentClickCount, 'targetClickCount=', targetClickCount);

      const button = document.getElementById('autoClickButton');
      if (button) {
        button.disabled = true;
        updateButtonState(true);
        updateButtonText(targetClickCount - currentClickCount);
      }

      // 启动弹出窗体监控
      startPopupMonitoring();

      // 启动独立浏览器页面处理
      handleIndependentBrowserWindows();

      // 如果是刷新后恢复，继续累计刷新次数，否则在新启动时清零
      chrome.storage.local.get(['noButtonRefreshAttempts'], res => {
        noButtonRefreshAttempts = res.noButtonRefreshAttempts || 0;
        console.log('恢复时的 noButtonRefreshAttempts =', noButtonRefreshAttempts);
        // 等待页面加载完成后继续点击
        setTimeout(findAndClickMarkComplete, 3000);
      });
    } else {
      // 如果不在自动点击过程中，清理状态重新开始
      console.log('不在自动点击过程中，清理状态重新开始');
      cleanupAutoClickState();
    }
  });
}

// 清理自动点击状态的函数
function cleanupAutoClickState() {
  console.log('清理自动点击状态');

  // 清除超时计时器
  if (noButtonTimeout) {
    clearTimeout(noButtonTimeout);
    noButtonTimeout = null;
    console.log('已清除超时计时器');
  }

  // 清理自动点击运行状态和已点击记录
  isAutoClickRunning = false;
  currentClickCount = 0;
  targetClickCount = 0;

  // 清理存储中的运行状态和已点击记录
  chrome.storage.local.set({
    isAutoClickRunning: false,
    currentClickCount: 0,
    targetClickCount: 0,
    clickedLaunchHrefs: [] // 清空已点击的 href 记录
  });

  // 确保弹窗监控已停止
  stopPopupMonitoring();

  // 确保按钮状态正常
  const button = document.getElementById('autoClickButton');
  if (button) {
    button.disabled = false;
    updateButtonState(false); // 恢复蓝色
    // 重置按钮文本为总次数
    chrome.storage.local.get(['clickCount'], function (result) {
      const clickCount = result.clickCount || 30;
      updateButtonText(clickCount);
    });
  }
}

// 获取已点击过的 Launch 按钮 href 列表
function getClickedLaunchHrefs(callback) {
  chrome.storage.local.get(['clickedLaunchHrefs'], function (result) {
    callback(new Set(result.clickedLaunchHrefs || []));
  });
}

// 记录已点击的 Launch 按钮 href
function addClickedLaunchHref(href) {
  getClickedLaunchHrefs(function (set) {
    set.add(href);
    chrome.storage.local.set({ clickedLaunchHrefs: Array.from(set) });
  });
}

function findAndClickMarkComplete() {
  console.log(`检查自动点击状态: isAutoClickRunning=${isAutoClickRunning}, currentClickCount=${currentClickCount}, targetClickCount=${targetClickCount}`);

  // 每次执行前都从存储中获取最新的状态，确保页面刷新后状态正确
  chrome.storage.local.get(['isAutoClickRunning', 'currentClickCount', 'targetClickCount'], function (result) {
    const storedIsRunning = result.isAutoClickRunning || false;
    const storedCurrentCount = result.currentClickCount || 0;
    const storedTargetCount = result.targetClickCount || 0;

    console.log(`存储中的状态: isAutoClickRunning=${storedIsRunning}, currentClickCount=${storedCurrentCount}, targetClickCount=${storedTargetCount}`);

    // 如果存储中的状态与全局变量不一致，使用存储中的状态
    if (storedIsRunning !== isAutoClickRunning || storedCurrentCount !== currentClickCount || storedTargetCount !== targetClickCount) {
      console.log('检测到状态不一致，使用存储中的状态');
      isAutoClickRunning = storedIsRunning;
      currentClickCount = storedCurrentCount;
      targetClickCount = storedTargetCount;
    }

    // 添加额外的状态检查
    console.log(`状态检查: isAutoClickRunning=${isAutoClickRunning}, currentClickCount=${currentClickCount}, targetClickCount=${targetClickCount}`);
    console.log(`条件检查: !isAutoClickRunning=${!isAutoClickRunning}, currentClickCount >= targetClickCount=${currentClickCount >= targetClickCount}`);
    console.log(`是否应该停止: ${!isAutoClickRunning || currentClickCount >= targetClickCount}`);

    // 如果存储中显示正在运行，但全局变量显示未运行，强制恢复状态
    if (storedIsRunning && !isAutoClickRunning) {
      console.log('检测到状态丢失，强制恢复运行状态');
      isAutoClickRunning = true;
      currentClickCount = storedCurrentCount;
      targetClickCount = storedTargetCount;
    }

    // 检查 targetClickCount 是否有效
    if (targetClickCount <= 0) {
      console.log('检测到 targetClickCount 无效，从存储中重新获取');
      chrome.storage.local.get(['clickCount'], function (result) {
        const clickCount = result.clickCount || 30;
        targetClickCount = clickCount;
        console.log('重新设置 targetClickCount:', targetClickCount);
      });
    }

    if (!isAutoClickRunning || currentClickCount >= targetClickCount) {
      console.log('自动点击完成，清理所有状态');
      console.log(`最终状态: currentClickCount=${currentClickCount}, targetClickCount=${targetClickCount}`);

      // 立即更新全局状态
      isAutoClickRunning = false;
      currentClickCount = 0;
      targetClickCount = 0;

      // 清理存储中的状态
      chrome.storage.local.set({
        isAutoClickRunning: false,
        currentClickCount: 0,
        targetClickCount: 0,
        clickedLaunchHrefs: [] // 完成所有点击后才清空已点击记录
      }, function () {
        console.log('存储状态已清理');

        // 确保按钮状态正确恢复
        const button = document.getElementById('autoClickButton');
        if (button) {
          button.disabled = false;
          updateButtonState(false); // 恢复蓝色
          // 重置按钮文本为总次数
          chrome.storage.local.get(['clickCount'], function (result) {
            const clickCount = result.clickCount || 30;
            updateButtonText(clickCount);
            console.log('按钮状态已恢复为蓝色，文本已重置');
          });
        }

        // 停止弹出窗体监控
        stopPopupMonitoring();
        console.log('自动点击功能已完全停止');
      });
      return;
    }

    // 继续执行点击逻辑
    continueClicking();
  });
}

// 继续执行点击逻辑的函数
function continueClicking() {
  // 优先查找 Mark Complete/标记"完成" 按钮（支持中英文环境）
  const allLinks = document.querySelectorAll('a');
  const allMarkCompleteButtons = Array.from(allLinks).filter(link => {
    const title = link.getAttribute('title') || '';
    const textContent = link.textContent?.trim() || '';
    console.log(`检查按钮: title="${title}", textContent="${textContent}"`);
    // 使用包含匹配，查找包含"标记"或"Mark Complete"的按钮
    return (title.includes('Mark Complete') || title.includes('标记')) ||
      (textContent.includes('Mark Complete') || textContent.includes('标记'));
  });

  console.log('页面中所有链接数量:', allLinks.length);
  console.log('找到的 Mark Complete/标记"完成" 按钮数量:', allMarkCompleteButtons.length);

  // 调试：显示所有可能的按钮
  Array.from(allLinks).forEach((link, index) => {
    const title = link.getAttribute('title') || '';
    if (title.includes('Complete') || title.includes('完成')) {
      console.log(`按钮 ${index}: title="${title}", textContent="${link.textContent?.trim()}"`);
    }
  });

  // 特别检查包含"标记"的按钮
  const markButtons = Array.from(allLinks).filter(link => {
    const title = link.getAttribute('title') || '';
    const textContent = link.textContent?.trim() || '';
    return title.includes('标记') || textContent.includes('标记');
  });
  console.log('包含"标记"的按钮数量:', markButtons.length);

  if (allMarkCompleteButtons.length > 0) {
    console.log('找到 Mark Complete/标记"完成" 按钮，准备点击');
    console.log(`点击前状态: currentClickCount=${currentClickCount}, targetClickCount=${targetClickCount}`);

    // 清除超时计时器，因为找到了可点击的按钮
    if (noButtonTimeout) {
      clearTimeout(noButtonTimeout);
      noButtonTimeout = null;
      console.log('找到 Mark Complete/标记"完成" 按钮，清除超时计时器');
    }

    allMarkCompleteButtons[0].click();
    // 统一计算点击次数：无论是 Mark Complete 还是 Launch，都算作一次点击
    currentClickCount++;
    chrome.storage.local.set({ currentClickCount: currentClickCount });
    updateButtonText(targetClickCount - currentClickCount);
    console.log(`点击后状态: currentClickCount=${currentClickCount}, targetClickCount=${targetClickCount}`);
    console.log(`点击第 ${currentClickCount}/${targetClickCount} 次 (Mark Complete/标记"完成")`);
    // 找到并点击后，重置连续未找到计数
    consecutiveNoButtonChecks = 0;

    // 检查是否已达到目标次数
    console.log(`检查是否达到目标: currentClickCount=${currentClickCount}, targetClickCount=${targetClickCount}`);
    if (currentClickCount >= targetClickCount) {
      console.log('已达到目标点击次数，停止自动点击');
      // 立即清理状态
      isAutoClickRunning = false;
      chrome.storage.local.set({
        isAutoClickRunning: false,
        currentClickCount: 0,
        targetClickCount: 0,
        clickedLaunchHrefs: []
      }, function () {
        console.log('存储状态已清理完成');
        const button = document.getElementById('autoClickButton');
        if (button) {
          button.disabled = false;
          updateButtonState(false);
          chrome.storage.local.get(['clickCount'], function (result) {
            const clickCount = result.clickCount || 30;
            updateButtonText(clickCount);
            console.log('按钮状态已恢复为蓝色，文本已重置为:', clickCount);
          });
        }
        stopPopupMonitoring();
        console.log('自动点击功能已完全停止');
      });
      return;
    }

    // 等待页面更新后继续点击（增加等待时间，避免页面刷新中断）
    setTimeout(findAndClickMarkComplete, 3000);
    return;
  }

  // 查找未被点击过的 Launch/启动 按钮（支持中英文环境）
  getClickedLaunchHrefs(function (clickedSet) {
    // 全局范围查找所有 Launch/启动 相关按钮（包括 test），稍后过滤
    const allLaunchButtons = document.querySelectorAll('a[title*="Launch"], a[title*="启动"]');
    console.log('页面内找到的所有 Launch/启动 按钮数量:', allLaunchButtons.length);

    // 输出每个按钮的详细信息
    Array.from(allLaunchButtons).forEach((btn, index) => {
      const href = btn.getAttribute('href') || '';
      const title = btn.getAttribute('title') || '';
      const isJsLink = href.toLowerCase().startsWith('javascript');
      const inClicked = !isJsLink && clickedSet.has(href);
      console.log(`按钮 ${index + 1}: title="${title}", href="${href}", isJsLink=${isJsLink}, 是否已点击(按href): ${inClicked}`);
    });

    // 过滤规则：
    // - 跳过 title='Launch test' 和 '启动 test'
    // - 对于普通 href（非 javascript:），按 clickedSet 去重
    // - 对于 javascript: 链接，不使用 href 去重，允许点击（页面会自行控制有效性）
    const launchButtons = Array.from(allLaunchButtons).filter(btn => {
      const href = (btn.getAttribute('href') || '').trim();
      const title = (btn.getAttribute('title') || '').trim();
      const isJsLink = href.toLowerCase().startsWith('javascript');
      // 支持中英文：只点击 'Launch' 或 '启动'，跳过测试按钮
      if (title !== 'Launch' && title !== '启动') return false;
      if (!isJsLink && clickedSet.has(href)) {
        console.log(`按钮 title="${title}", href="${href}": 因为已点击过(按href)而跳过`);
        return false;
      }
      console.log(`按钮 title="${title}", href="${href}": 将被点击`);
      return true;
    });

    console.log('最终可点击的 Launch/启动 按钮数量:', launchButtons.length);

    if (launchButtons.length > 0) {
      const btn = launchButtons[0];
      const href = btn.getAttribute('href') || '';
      addClickedLaunchHref(href);
      console.log('点击未被点击过的 Launch/启动 按钮:', href);
      console.log(`点击前状态: currentClickCount=${currentClickCount}, targetClickCount=${targetClickCount}`);

      // 清除超时计时器，因为找到了可点击的按钮
      if (noButtonTimeout) {
        clearTimeout(noButtonTimeout);
        noButtonTimeout = null;
        console.log('找到 Launch/启动 按钮，清除超时计时器');
      }

      btn.click();
      // 统一计算点击次数：无论是 Mark Complete 还是 Launch，都算作一次点击
      currentClickCount++;
      chrome.storage.local.set({ currentClickCount: currentClickCount });
      updateButtonText(targetClickCount - currentClickCount);
      console.log(`点击后状态: currentClickCount=${currentClickCount}, targetClickCount=${targetClickCount}`);
      console.log(`点击第 ${currentClickCount}/${targetClickCount} 次 (Launch/启动)`);
      // 找到并点击后，重置连续未找到计数
      consecutiveNoButtonChecks = 0;

      // 检查是否已达到目标次数
      console.log(`检查是否达到目标: currentClickCount=${currentClickCount}, targetClickCount=${targetClickCount}`);
      if (currentClickCount >= targetClickCount) {
        console.log('已达到目标点击次数，停止自动点击');
        // 立即清理状态
        isAutoClickRunning = false;
        chrome.storage.local.set({
          isAutoClickRunning: false,
          currentClickCount: 0,
          targetClickCount: 0,
          clickedLaunchHrefs: []
        }, function () {
          console.log('存储状态已清理完成');
          const button = document.getElementById('autoClickButton');
          if (button) {
            button.disabled = false;
            updateButtonState(false);
            chrome.storage.local.get(['clickCount'], function (result) {
              const clickCount = result.clickCount || 30;
              updateButtonText(clickCount);
              console.log('按钮状态已恢复为蓝色，文本已重置为:', clickCount);
            });
          }
          stopPopupMonitoring();
          console.log('自动点击功能已完全停止');
        });
        return;
      }

      setTimeout(findAndClickMarkComplete, 3000);
      return;
    }

    // 如果都没有找到按钮，累计未找到次数；连续3次时触发刷新
    consecutiveNoButtonChecks += 1;
    console.log('未找到 Mark Complete/标记"完成" 或 Launch/启动 按钮，本次累计未找到次数:', consecutiveNoButtonChecks);
    if (consecutiveNoButtonChecks >= 3) {
      consecutiveNoButtonChecks = 0;
      // 跨刷新累计尝试次数
      chrome.storage.local.get(['noButtonRefreshAttempts'], res => {
        noButtonRefreshAttempts = (res.noButtonRefreshAttempts || 0) + 1;
        console.log('触发刷新，累计刷新尝试次数:', noButtonRefreshAttempts);
        chrome.storage.local.set({
          isAutoClickRunning: true,
          currentClickCount: currentClickCount,
          targetClickCount: targetClickCount,
          noButtonRefreshAttempts: noButtonRefreshAttempts
        }, () => {
          if (noButtonRefreshAttempts >= 3) {
            console.log('已连续刷新3次仍无按钮，退出执行');
            // 重置状态并退出
            chrome.storage.local.set({
              isAutoClickRunning: false,
              currentClickCount: 0,
              targetClickCount: 0,
              clickedLaunchHrefs: [],
              noButtonRefreshAttempts: 0
            }, () => {
              isAutoClickRunning = false;
              currentClickCount = 0;
              targetClickCount = 0;
              const button = document.getElementById('autoClickButton');
              if (button) {
                button.disabled = false;
                updateButtonState(false);
                chrome.storage.local.get(['clickCount'], function (result) {
                  const clickCount = result.clickCount || 30;
                  updateButtonText(clickCount);
                });
              }
              stopPopupMonitoring();
            });
          } else {
            // 刷新页面以获取新按钮
            window.location.reload();
          }
        });
      });
      return;
    }
    // 未达到刷新阈值，继续定时重试
    setTimeout(findAndClickMarkComplete, 1000);
  });
}

// 初始化悬浮按钮
function initializeAutoClickButton() {
  // 只在 Cornerstone 页面显示悬浮按钮
  if (!window.location.href.includes('medtronic.csod.com')) {
    return;
  }

  // 检查开关
  chrome.storage.local.get(['autoClickEnabled'], function (result) {
    if (!result.autoClickEnabled) {
      // 未开启自动点击，不显示按钮
      return;
    }

    const button = createFloatingButton();

    // 初始化按钮文本（显示设置中的点击次数）
    initializeButtonText();

    // 添加点击事件
    button.addEventListener('click', function () {
      console.log('悬浮按钮被点击');
      if (!isAutoClickRunning) {
        // 从存储中获取最新的点击次数设置
        chrome.storage.local.get(['clickCount'], function (result) {
          const clickCount = result.clickCount || 30;
          console.log('开始执行自动点击，目标次数:', clickCount);
          console.log('设置前的状态: isAutoClickRunning=', isAutoClickRunning, 'currentClickCount=', currentClickCount, 'targetClickCount=', targetClickCount);
          isAutoClickRunning = true;
          currentClickCount = 0;
          targetClickCount = clickCount;
          console.log('设置后的状态: isAutoClickRunning=', isAutoClickRunning, 'currentClickCount=', currentClickCount, 'targetClickCount=', targetClickCount);

          // 保存状态到存储，防止页面刷新丢失
          chrome.storage.local.set({
            isAutoClickRunning: true,
            currentClickCount: 0,
            targetClickCount: clickCount,
            // 新一轮开始时重置去重列表，避免上次残留导致后续点击被跳过
            clickedLaunchHrefs: [],
            noButtonRefreshAttempts: 0
          });

          button.disabled = true;
          updateButtonState(true); // 设置为绿色

          // 启动弹出窗体监控
          startPopupMonitoring();

          // 启动独立浏览器页面处理
          handleIndependentBrowserWindows();

          // 立即开始第一次点击
          console.log('开始连续点击，目标次数:', targetClickCount);
          findAndClickMarkComplete();
        });
      } else {
        console.log('自动点击已在运行中，当前进度:', currentClickCount, '/', targetClickCount);
      }
    });
  });
}

// 在页面加载完成后初始化按钮
if (document.readyState === 'complete') {
  initializeAutoClickButton();
  checkAndContinueAutoClick();
} else {
  window.addEventListener('load', () => {
    initializeAutoClickButton();
    checkAndContinueAutoClick();
  });
}

// 监听DOM变化
const observer = new MutationObserver((mutations) => {
  mutations.forEach((mutation) => {
    if (mutation.addedNodes.length) {
      console.log('检测到DOM变化，尝试填充');
      autoFillCredentials();
    }
  });
});

// 配置观察选项
const config = {
  childList: true,
  subtree: true
};

// 开始观察
observer.observe(document.body, config);

// 等待DOM加载完成后执行自动填充
console.log('当前文档状态:', document.readyState);
if (document.readyState === 'complete') {
  console.log('文档已完全加载，立即执行自动填充');
  autoFillCredentials();
} else {
  console.log('文档尚未完全加载，添加load事件监听器');
  window.addEventListener('load', () => {
    console.log('文档加载完成，执行自动填充');
    autoFillCredentials();
  });
}

// 监听存储变化
chrome.storage.onChanged.addListener((changes, namespace) => {
  console.log('检测到存储变化:', { changes, namespace });
  if (namespace === 'local') {
    if (changes.username || changes.password) {
      console.log('用户名或密码发生变化，重新执行自动填充');
      autoFillCredentials();
    }
    if (changes.clickCount) {
      console.log('点击次数设置发生变化:', changes.clickCount.newValue);
      // 只有在未运行时才更新按钮文本
      if (!isAutoClickRunning) {
        updateButtonText(changes.clickCount.newValue);
      }
    }
  }
});

// 弹出窗体识别和自动关闭功能 - 只在自动点击运行时启用
let popupObserver = null;
let popupInterval = null;

// 查找并关闭弹出窗体
function findAndClosePopup() {
  // 只在自动点击运行时才执行
  if (!isAutoClickRunning) {
    return;
  }

  // 常见的弹出窗体选择器
  const popupSelectors = [
    // 模态框
    '.modal',
    '.modal-dialog',
    '.modal-content',
    '[role="dialog"]',
    '[aria-modal="true"]',
    // 弹出框
    '.popup',
    '.popover',
    '.tooltip',
    // 特定类名
    '.p-dialog',
    '.p-overlay-panel',
    '.p-confirm-dialog',
    // 关闭按钮
    '.close',
    '.btn-close',
    '[data-dismiss="modal"]',
    '[aria-label="Close"]',
    '[title="Close"]'
  ];

  let popupFound = false;

  // 查找弹出窗体
  for (const selector of popupSelectors) {
    try {
      const elements = document.querySelectorAll(selector);
      if (elements.length > 0) {
        console.log('找到弹出窗体:', selector);
        popupFound = true;

        // 直接按ESC键关闭弹窗，避免点击页面按钮
        console.log('按ESC键关闭弹窗');
        document.dispatchEvent(new KeyboardEvent('keydown', {
          key: 'Escape',
          keyCode: 27,
          which: 27,
          bubbles: true
        }));

        return true;
      }
    } catch (error) {
      console.log('查找弹出窗体时出错:', error);
    }
  }

  // 查找iframe中的弹出窗体
  const iframes = document.getElementsByTagName('iframe');
  for (const iframe of iframes) {
    try {
      const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
      for (const selector of popupSelectors) {
        try {
          const elements = iframeDoc.querySelectorAll(selector);
          if (elements.length > 0) {
            console.log('在iframe中找到弹出窗体:', selector);
            popupFound = true;

            // 在iframe中按ESC键关闭弹窗
            console.log('在iframe中按ESC键关闭弹窗');
            iframeDoc.dispatchEvent(new KeyboardEvent('keydown', {
              key: 'Escape',
              keyCode: 27,
              which: 27,
              bubbles: true
            }));

            return true;
          }
        } catch (error) {
          console.log('在iframe中查找弹出窗体时出错:', error);
        }
      }
    } catch (error) {
      console.log('访问iframe失败:', error);
    }
  }

  if (!popupFound) {
    console.log('未找到弹出窗体');
  }
  return false;
}

// 启动弹出窗体监控
function startPopupMonitoring() {
  // 检查是否在Cornerstone页面
  if (!window.location.href.includes('medtronic.csod.com')) {
    return;
  }

  console.log('启动弹出窗体监控');

  // 监听DOM变化，检测新出现的弹出窗体
  if (!popupObserver) {
    popupObserver = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        if (mutation.addedNodes.length) {
          // 检查是否添加了弹出窗体
          const newNodes = Array.from(mutation.addedNodes);
          newNodes.forEach(node => {
            if (node.nodeType === Node.ELEMENT_NODE) {
              // 检查新添加的元素是否是弹出窗体
              const popupSelectors = ['.modal', '.modal-dialog', '.modal-content', '[role="dialog"]', '[aria-modal="true"]', '.popup', '.popover', '.tooltip', '.p-dialog', '.p-overlay-panel', '.p-confirm-dialog'];
              for (const selector of popupSelectors) {
                if (node.matches && node.matches(selector)) {
                  console.log('检测到新的弹出窗体:', selector);
                  // 4秒后自动关闭
                  setTimeout(() => {
                    findAndClosePopup();
                  }, 4000);
                  return;
                }
              }

              // 检查新添加的元素内部是否包含弹出窗体
              if (node.querySelectorAll) {
                for (const selector of popupSelectors) {
                  const popup = node.querySelector(selector);
                  if (popup) {
                    console.log('检测到新元素中包含弹出窗体:', selector);
                    // 4秒后自动关闭
                    setTimeout(() => {
                      findAndClosePopup();
                    }, 4000);
                    return;
                  }
                }
              }
            }
          });
        }
      });
    });

    // 配置观察选项
    const popupConfig = {
      childList: true,
      subtree: true
    };

    // 开始观察
    popupObserver.observe(document.body, popupConfig);
  }

  // 定期检查现有弹出窗体（每5秒检查一次）
  if (!popupInterval) {
    popupInterval = setInterval(() => {
      findAndClosePopup();
    }, 5000);
  }
}

// 停止弹出窗体监控
function stopPopupMonitoring() {
  console.log('停止弹出窗体监控');

  if (popupObserver) {
    popupObserver.disconnect();
    popupObserver = null;
  }

  if (popupInterval) {
    clearInterval(popupInterval);
    popupInterval = null;
  }

  // 清除超时计时器
  if (noButtonTimeout) {
    clearTimeout(noButtonTimeout);
    noButtonTimeout = null;
    console.log('已清除超时计时器');
  }
}

// 处理独立浏览器页面关闭功能
function handleIndependentBrowserWindows() {
  // 检查是否在Cornerstone页面
  if (!window.location.href.includes('medtronic.csod.com')) {
    return;
  }

  // 检查是否开启了自动点击功能
  chrome.storage.local.get(['autoClickEnabled'], function (result) {
    if (!result.autoClickEnabled) {
      console.log('自动点击功能未开启，跳过独立浏览器页面处理');
      return;
    }

    console.log('初始化独立浏览器页面处理功能');

    // 监听Launch/启动按钮点击事件
    function handleLaunchButtonClick() {
      // 查找所有Launch/启动按钮
      const launchButtons = document.querySelectorAll('a[title="Launch"], a[title="启动"]');
      launchButtons.forEach(button => {
        // 移除之前的事件监听器（避免重复）
        button.removeEventListener('click', handleNewWindow);
        // 添加新的事件监听器
        button.addEventListener('click', handleNewWindow);
      });
    }

    // 处理新窗口打开
    function handleNewWindow(event) {
      console.log('检测到Launch/启动按钮点击，准备处理新窗口');

      // 获取目标URL
      const targetUrl = event.target.href || event.target.getAttribute('href');
      if (targetUrl) {
        console.log('目标URL:', targetUrl);

        // 尝试通过chrome.tabs API关闭新打开的标签页
        // 注意：这需要background script的支持
        chrome.runtime.sendMessage({
          action: 'monitorNewTab',
          url: targetUrl
        }, (response) => {
          if (response && response.success) {
            console.log('已设置监控新标签页');
          } else {
            console.log('无法设置监控新标签页');
          }
        });
      }
    }

    // 使用MutationObserver监听Launch按钮的出现
    const launchObserver = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        if (mutation.addedNodes.length) {
          mutation.addedNodes.forEach(node => {
            if (node.nodeType === Node.ELEMENT_NODE) {
              // 检查新添加的元素是否是Launch/启动按钮
              if (node.matches && (node.matches('a[title="Launch"]') || node.matches('a[title="启动"]'))) {
                console.log('检测到新的Launch/启动按钮');
                handleLaunchButtonClick();
              }
              // 检查新添加的元素内部是否包含Launch/启动按钮
              if (node.querySelectorAll) {
                const launchButtons = node.querySelectorAll('a[title="Launch"], a[title="启动"]');
                if (launchButtons.length > 0) {
                  console.log('检测到新元素中包含Launch/启动按钮');
                  handleLaunchButtonClick();
                }
              }
            }
          });
        }
      });
    });

    // 配置观察选项
    const launchConfig = {
      childList: true,
      subtree: true
    };

    // 开始观察
    launchObserver.observe(document.body, launchConfig);

    // 初始检查现有的Launch/启动按钮
    handleLaunchButtonClick();
  });
}

// 在页面加载完成后初始化独立浏览器页面处理功能
// 注意：该函数现在只在autoClickEnabled为true时才执行，不需要在页面加载时自动调用
// if (document.readyState === 'complete') {
//   handleIndependentBrowserWindows();
// } else {
//   window.addEventListener('load', handleIndependentBrowserWindows);
// }