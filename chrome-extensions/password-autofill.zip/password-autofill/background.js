// Background script for handling new tab monitoring and closing

let monitoredUrls = new Set();
let mainTabId = null;

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('Background script received message:', request);
  if (request.action === 'monitorNewTab') {
    const url = request.url;
    // 记录主页面tabId
    if (sender && sender.tab && sender.tab.id) {
      mainTabId = sender.tab.id;
      console.log('Set mainTabId:', mainTabId);
    }
    monitoredUrls.add(url);
    sendResponse({ success: true });
  }
  return true;
});

// 只关闭新建且不是主tabId的标签页
chrome.tabs.onCreated.addListener((tab) => {
  console.log('New tab created:', tab.url, 'tabId:', tab.id);
  for (const monitoredUrl of monitoredUrls) {
    if (tab.url && (tab.url.includes(monitoredUrl) || tab.url.includes(monitoredUrl.replace('javascript:void(0);', '')))) {
      if (mainTabId !== null && tab.id !== mainTabId) {
        console.log('Found monitored URL in new tab, closing:', tab.url);
        setTimeout(() => {
          chrome.tabs.remove(tab.id, () => {
            console.log('New tab closed:', tab.id);
          });
        }, 2000);
        monitoredUrls.delete(monitoredUrl);
      }
      break;
    }
  }
});

// 只关闭新建且不是主tabId的标签页
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url) {
    for (const monitoredUrl of monitoredUrls) {
      if (tab.url.includes(monitoredUrl) || tab.url.includes(monitoredUrl.replace('javascript:void(0);', ''))) {
        if (mainTabId !== null && tabId !== mainTabId) {
          console.log('Found monitored URL, closing tab:', tab.url);
          setTimeout(() => {
            chrome.tabs.remove(tabId, () => {
              console.log('Tab closed:', tabId);
            });
          }, 2000);
          monitoredUrls.delete(monitoredUrl);
        }
        break;
      }
    }
  }
});

// 缓存的凭据
let cachedCredentials = {
  username: '',
  password: ''
};

// 更新缓存的凭据
function updateCachedCredentials() {
  chrome.storage.local.get(['username', 'password'], (result) => {
    if (result.username && result.password) {
      cachedCredentials.username = result.username;
      cachedCredentials.password = result.password;
      console.log('Credentials cached for Basic Auth');
    }
  });
}

// 初始化时获取凭据
updateCachedCredentials();

// 监听存储变化自动更新缓存
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && (changes.username || changes.password)) {
    updateCachedCredentials();
  }
});

// 监听 Basic Auth 认证请求
chrome.webRequest.onAuthRequired.addListener(
  function (details) {
    console.log('Auth required for:', details.url);
    if (details.url.includes('khplm.medtronic.com.cn') && cachedCredentials.username && cachedCredentials.password) {
      console.log('Providing cached credentials for Windchill');
      return {
        authCredentials: {
          username: cachedCredentials.username,
          password: cachedCredentials.password
        }
      };
    }
    return {};
  },
  { urls: ["https://khplm.medtronic.com.cn/*"] },
  ["blocking"]
);

console.log('Background script loaded');

// 注册右键菜单
function updateContextMenu() {
  chrome.storage.local.get(['autoClickEnabled', 'autoClosePopup'], function (result) {
    const enabled = !!result.autoClickEnabled;
    const popupEnabled = !!result.autoClosePopup;
    chrome.contextMenus.removeAll(() => {
      chrome.contextMenus.create({
        id: 'toggleAutoClick',
        title: enabled ? '🟢 自动点击已开启 (点击关闭)' : '⚪ 自动点击已关闭 (点击开启)',
        contexts: ['action']
      });

      chrome.contextMenus.create({
        id: 'toggleAutoClosePopup',
        title: popupEnabled ? '🟢 自动关闭弹窗已开启 (点击关闭)' : '⚪ 自动关闭弹窗已关闭 (点击开启)',
        contexts: ['action']
      });
    });
  });
}

chrome.runtime.onInstalled.addListener(() => {
  updateContextMenu();
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === 'toggleAutoClick') {
    chrome.storage.local.get(['autoClickEnabled'], function (result) {
      const enabled = !!result.autoClickEnabled;
      chrome.storage.local.set({ autoClickEnabled: !enabled }, () => {
        updateContextMenu();

        // 刷新所有已打开的 Cornerstone 页面
        chrome.tabs.query({ url: "*://medtronic.csod.com/*" }, (tabs) => {
          tabs.forEach(tab => {
            console.log('刷新 Cornerstone 页面:', tab.url);
            chrome.tabs.reload(tab.id);
          });
        });
      });
    });
  }

  if (info.menuItemId === 'toggleAutoClosePopup') {
    chrome.storage.local.get(['autoClosePopup'], function (result) {
      const popupEnabled = !!result.autoClosePopup;
      chrome.storage.local.set({ autoClosePopup: !popupEnabled }, () => {
        updateContextMenu();

        // 刷新所有已打开的 Cornerstone 页面
        chrome.tabs.query({ url: "*://medtronic.csod.com/*" }, (tabs) => {
          tabs.forEach(tab => {
            console.log('刷新 Cornerstone 页面:', tab.url);
            chrome.tabs.reload(tab.id);
          });
        });
      });
    });
  }
});

// 监听设置变化，动态更新菜单和定时任务
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local') {
    if (changes.autoClickEnabled) {
      updateContextMenu();
    }
    if (changes.dailyOpenEnabled || changes.dailyOpenTime) {
      updateDailyAlarm();
    }
  }
});

// 计算下一个运行时间
function getNextRunTime(targetTimeStr = "09:00") {
  const [hours, minutes] = targetTimeStr.split(':').map(Number);
  const now = new Date();
  const nextRun = new Date(now);
  nextRun.setHours(hours, minutes, 0, 0);

  // 如果今天已经过了设定时间，则设为明天
  if (now > nextRun) {
    nextRun.setDate(now.getDate() + 1);
  }
  return nextRun.getTime();
}

// 更新定时任务
function updateDailyAlarm() {
  chrome.storage.local.get(['dailyOpenEnabled', 'dailyOpenTime'], (result) => {
    if (result.dailyOpenEnabled) {
      // 默认 09:00
      const timeStr = result.dailyOpenTime || "09:00";
      chrome.alarms.create('dailyOpenPages', {
        when: getNextRunTime(timeStr),
        periodInMinutes: 1440 // 24小时
      });
      console.log(`Daily alarm set for: ${new Date(getNextRunTime(timeStr)).toLocaleString()} (Target: ${timeStr})`);
    } else {
      chrome.alarms.clear('dailyOpenPages');
      console.log('Daily alarm cleared');
    }
  });
}

// 监听定时任务触发
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'dailyOpenPages') {
    console.log('Daily alarm triggered, opening pages...');
    const urls = [
      'https://khplm.medtronic.com.cn/Windchill/app/#ptc1/homepage',
      'http://ehr.medtronic.com.cn/Authentication/Login'
    ];

    urls.forEach(url => {
      chrome.tabs.create({ url: url });
    });
  }
});

// 初始化或更新定时器
updateDailyAlarm();