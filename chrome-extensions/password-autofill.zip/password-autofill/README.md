# Medtronic Smart Assistant

Medtronic Smart Assistant 是一个Chrome浏览器扩展，旨在提高Medtronic员工日常工作效率。它提供了多个系统的快速访问、自动化填充及定时启动功能。

## 功能特点

### 1. 快速访问
- 一键访问Windchill系统
- 一键访问Cornerstone学习平台
- 一键访问EHR系统

### 2. 自动填充功能
- **Windchill系统**: 支持网页表单和系统弹窗(Basic Auth)的自动登录
- **EHR系统**: 账号密码自动填充

### 3. Cornerstone自动化
- 自动点击功能（可选启用）
- 自动完成课程进度

### 4. 每日定时启动
- 可开启"每日自动打开页面"
- 每天 09:00 自动打开 Windchill 和 EHR 页面

## 安装方法

1. 打开Chrome浏览器，进入扩展程序页面：
   - 在地址栏输入：`chrome://extensions/`
   - 或者点击菜单 -> 更多工具 -> 扩展程序

2. 启用"开发者模式"（右上角开关）

3. 安装扩展：
   - 点击"加载已解压的扩展程序"
   - 选择本插件所在文件夹

## 使用说明

### 快速访问
1. 点击Chrome工具栏中的插件图标
2. 在"快捷链接"标签页中选择要访问的系统
3. 点击对应的按钮即可快速打开系统

### 系统设置
1. 点击"设置"标签页
2. 根据需要配置各系统：

#### Windchill设置
- 输入Windchill系统的用户名和密码
- 点击"保存"按钮
- 支持处理系统原生登录弹窗

#### Cornerstone设置
- 启用/禁用自动点击功能
- 开启后会自动处理课程进度

#### EHR设置
- 输入EHR系统的用户名和密码
- 点击"保存"按钮

#### 每日定时
- 开启"每日自动打开页面"开关
- 插件将在每天 09:00 自动为你打开工作页面

## 安全说明

- 所有密码信息均使用Chrome安全存储机制保存
- 账号信息仅在本地保存，不会上传到任何服务器
- 插件仅在指定的Medtronic系统域名下运行

## 支持的系统

- Windchill: https://khplm.medtronic.com.cn
- Cornerstone: https://medtronic.csod.com
- EHR系统: http://ehr.medtronic.com.cn

## 更新日志

### v1.2 (Current)
- **新增**: 每日 09:00 定时自动打开 Windchill 和 EHR
- **增强**: Windchill 登录支持系统原生弹窗 (Basic Auth)
- **移除**: 未使用的 PowerBI 功能

### v1.1
- 修复部分Bug

### v1.0
- 初始版本发布
- 支持三个系统的快速访问
- 实现账号密码自动填充
- 添加Cornerstone自动点击功能

## 常见问题

### 如何在无痕模式(Incognito)下使用？
默认情况下，Chrome 扩展在无痕模式下是禁用的。如需开启：
1. 在浏览器地址栏输入 `chrome://extensions/`
2. 找到本插件，点击 **详细信息 (Details)** 按钮
3. 向下滚动，找到 **在无痕模式下启用 (Allow in Incognito)** 选项
4. 点击开关将其启用即可