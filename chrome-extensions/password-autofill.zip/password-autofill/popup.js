document.addEventListener('DOMContentLoaded', function () {
  // 初始化标签页状态
  const tabButtons = document.querySelectorAll('.tab-button');
  const tabContents = document.querySelectorAll('.tab-content');

  // 确保只有一个标签页是活动的
  function setActiveTab(tabId) {
    tabButtons.forEach(btn => {
      btn.classList.remove('active');
      if (btn.getAttribute('data-tab') === tabId) {
        btn.classList.add('active');
      }
    });

    tabContents.forEach(content => {
      content.classList.remove('active');
      if (content.id === tabId) {
        content.classList.add('active');
      }
    });
  }

  // 标签切换功能
  tabButtons.forEach(button => {
    button.addEventListener('click', () => {
      const tabId = button.getAttribute('data-tab');
      setActiveTab(tabId);
    });
  });

  // Windchill设置
  const usernameInput = document.getElementById('username');
  const passwordInput = document.getElementById('password');
  const saveButton = document.getElementById('save');

  // 加载保存的Windchill设置
  chrome.storage.local.get(['username', 'password'], function (result) {
    if (result.username) {
      usernameInput.value = result.username;
    }
    if (result.password) {
      passwordInput.value = result.password;
    }
  });

  // 保存Windchill设置
  saveButton.addEventListener('click', function () {
    const username = usernameInput.value;
    const password = passwordInput.value;

    chrome.storage.local.set({
      username: username,
      password: password
    }, function () {
      showStatus('Windchill设置已保存', 'success');
    });
  });

  // Cornerstone点击次数设置
  const clickCountInput = document.getElementById('clickCount');
  const saveClickCountButton = document.getElementById('saveClickCount');

  // 加载保存的点击次数
  chrome.storage.local.get(['clickCount'], function (result) {
    if (result.clickCount) {
      clickCountInput.value = result.clickCount;
    }
  });

  // 保存点击次数设置
  saveClickCountButton.addEventListener('click', function () {
    const clickCount = parseInt(clickCountInput.value);
    if (isNaN(clickCount) || clickCount < 1 || clickCount > 100) {
      showStatus('请输入1-100之间的数字', 'error');
      return;
    }

    chrome.storage.local.set({
      clickCount: clickCount
    }, function () {
      showStatus('点击次数设置已保存', 'success');
    });
  });

  // EHR设置
  const ehrUsernameInput = document.getElementById('ehrUsername');
  const ehrPasswordInput = document.getElementById('ehrPassword');
  const saveEhrButton = document.getElementById('saveEhr');

  // 加载保存的EHR设置
  chrome.storage.local.get(['Login1', 'Password1'], function (items) {
    if (items.Login1) {
      ehrUsernameInput.value = items.Login1;
    }
    if (items.Password1) {
      ehrPasswordInput.value = items.Password1;
    }
  });

  // 保存EHR设置
  saveEhrButton.addEventListener('click', function () {
    const ehrUsername = ehrUsernameInput.value;
    const ehrPassword = ehrPasswordInput.value;

    chrome.storage.local.set({
      'Login1': ehrUsername,
      'Password1': ehrPassword
    }, function () {
      showStatus('EHR设置已保存', 'success');
    });
  });

  // 加载保存的账号密码
  chrome.storage.local.get(['username', 'password', 'Login1', 'Password1', 'clickCount'], function (result) {
    if (result.username) {
      usernameInput.value = result.username;
    }
    if (result.password) {
      passwordInput.value = result.password;
    }
    if (result.Login1) {
      ehrUsernameInput.value = result.Login1;
    }
    if (result.Password1) {
      ehrPasswordInput.value = result.Password1;
    }
    if (result.clickCount) {
      clickCountInput.value = result.clickCount;
    }
  });

  // 每日自动打开开关逻辑
  const dailyOpenSwitch = document.getElementById('dailyOpenSwitch');
  const dailyOpenTimeInput = document.getElementById('dailyOpenTime');
  const saveTimeButton = document.getElementById('saveTime');

  if (dailyOpenSwitch && dailyOpenTimeInput) {
    // 初始化状态和时间
    chrome.storage.local.get(['dailyOpenEnabled', 'dailyOpenTime'], function (result) {
      dailyOpenSwitch.checked = !!result.dailyOpenEnabled;
      if (result.dailyOpenTime) {
        dailyOpenTimeInput.value = result.dailyOpenTime;
      }
    });

    // 开关切换事件
    dailyOpenSwitch.addEventListener('change', function () {
      const enabled = dailyOpenSwitch.checked;
      chrome.storage.local.set({ dailyOpenEnabled: enabled }, () => {
        showStatus(enabled ? '每日自动打开已开启' : '每日自动打开已关闭', enabled ? 'success' : '');
      });
    });

    // 保存时间事件
    saveTimeButton.addEventListener('click', function () {
      const time = dailyOpenTimeInput.value;
      if (!time) {
        showStatus('请选择有效时间', 'error');
        return;
      }
      chrome.storage.local.set({ dailyOpenTime: time }, () => {
        showStatus('启动时间已保存', 'success');
      });
    });
  }

  // Cornerstone自动点击开关逻辑
  const autoClickSwitch = document.getElementById('autoClickSwitch');
  if (autoClickSwitch) {
    // 初始化状态
    chrome.storage.local.get(['autoClickEnabled'], function (result) {
      autoClickSwitch.checked = !!result.autoClickEnabled;
    });
    // 切换事件
    autoClickSwitch.addEventListener('change', function () {
      chrome.storage.local.set({ autoClickEnabled: autoClickSwitch.checked }, () => {
        // 刷新所有已打开的 Cornerstone 页面
        chrome.tabs.query({ url: "*://medtronic.csod.com/*" }, (tabs) => {
          tabs.forEach(tab => {
            console.log('刷新 Cornerstone 页面:', tab.url);
            chrome.tabs.reload(tab.id);
          });
        });
      });
    });
  }

  // 状态显示函数
  function showStatus(message, type) {
    const status = document.getElementById('status');
    status.textContent = message;
    status.className = 'status ' + type;
    status.style.display = 'block';
    setTimeout(function () {
      status.style.display = 'none';
    }, 2000);
  }
});